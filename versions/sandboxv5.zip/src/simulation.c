#include "simulation.h"

#include <math.h> //sqrtf()
#include <string.h> //memcpy()

#ifndef M_PI
	#define M_PI 3.14159265358979323846
#endif

#define DEG2RAD(x) ((x)*(M_PI/180.f))
#define RAD2DEG(x) ((x)*(180.f/M_PI))

#define errLog(message) \
	fprintf(stderr, "\nFile: %s, Function: %s, Line: %d, Note: %s\n", __FILE__, __FUNCTION__, __LINE__, message);


static float maxf(float a, float b){
    return (a > b) ? a : b;
}

static float minf(float a, float b){
    return (a < b) ? a : b;
}

static float lerp(float s, float e, float t)
{
	return s + (e - s) * t;
}

static float blerp(float c00, float c10, float c01, float c11, float tx, float ty)
{
	//    return lerp(lerp(c00, c10, tx), lerp(c01, c11, tx), ty);
	float s = c00 + (c10 - c00) * tx;
	float e = c01 + (c11 - c01) * tx;
	return (s + (e - s) * ty);
}



//Advects a density matrix along velocity vectors of some fluid 
void advect(float* densityMatrix, float* bufferMatrix, vec2f_t* velocityVector, int w, int h, float dTime){
    //We are using a semi-lagrangian advection scheme where we take a timestep backwards along the velocity vector and move that density to our position.
	for(int y = 2; y < h - 2; y++){
		for(int x = 2; x < w - 2; x++){

            //Get velocity vector
            float dX = (velocityVector[x+y*w].x)*dTime;
            float dY = (velocityVector[x+y*w].y)*dTime;


            int xdx = (int)(x-dX);
            int ydy = (int)(y-dY);

            if(xdx < 3 || xdx > w - 3  || ydy < 3 || ydy > h - 3) continue;

            //Sample the four points around the target cell and interpolate between them
            float f1 = densityMatrix[(xdx)  +(ydy)*w];
            float f2 = densityMatrix[(xdx+1)+(ydy)*w];
            float f3 = densityMatrix[(xdx)  +(ydy+1)*w];
            float f4 = densityMatrix[(xdx+1)+(ydy+1)*w];

            float tX = (x-dX) - xdx;
            float tY = (y-dY) - ydy;

            float amountTransported = blerp(f1,f2,f3,f4,tX,tY);

            //Get factor of each sampled point
            // float r1 = (1-tX)*(1-tY);
            // float r2 = (tX)  *(1-tY);
            // float r3 = (1-tX)*(tY);
            // float r4 = (tX)  *(tY);

            // printf("%f %f = %f %f %f %f = %f\n",tX,tY,r1,r2,r3,r4,r1+r2+r3+r4); //Validate that the sum of r is 1
            // printf("\n");
            // printf("(%f)\t(%f)\n(%f)\t(%f) = (%f)\n",
            // foamLevelBuffer[((int)(x-dX))  +((int)(y-dY))*map.w],
            // foamLevelBuffer[((int)(x-dX)+1)+((int)(y-dY))*map.w],
            // foamLevelBuffer[((int)(x-dX))  +((int)(y-dY)+1)*map.w],
            // foamLevelBuffer[((int)(x-dX)+1)+((int)(y-dY)+1)*map.w],
            // foamLevelBuffer[(x)+(y)*map.w]);

            // printf("%f %f %f %f = %f = %f\n", amountTransported * r1, amountTransported * r2, amountTransported * r3, amountTransported * r4, amountTransported * r1+ amountTransported * r2+ amountTransported * r3 + amountTransported * r4,amountTransported);

            // foamLevelBuffer[((int)(x-dX))  +((int)(y-dY))*map.w] -= amountTransported   * r1;
            // foamLevelBuffer[((int)(x-dX)+1)+((int)(y-dY))*map.w] -= amountTransported   * r2;
            // foamLevelBuffer[((int)(x-dX))  +((int)(y-dY)+1)*map.w] -= amountTransported * r3;
            // foamLevelBuffer[((int)(x-dX)+1)+((int)(y-dY)+1)*map.w] -= amountTransported * r4;

            bufferMatrix[(x)+(y)*w] = amountTransported;
		}
	}
	memcpy(densityMatrix,bufferMatrix,sizeof(float)*w*h);
}

//Relax some sort of matter (Probably sand) over a terrain. 
void relax(float* subject, float* terrain, float talusAngle, float g, int w, int h, float dTime){

    talusAngle = DEG2RAD(talusAngle);
    float maxSlope = tanf(talusAngle);

	int jMax, jMin, iMax, iMin;
	for (int y = 2; y < h - 1; y++)
	{
		iMin = (y == 2) ? 0 : -1;
		iMax = (y == h - 2) ? 0 : 1;
		for (int x = 2; x < w - 1; x++)
		{
			jMin = (x == 2) ? 0 : -1;
			jMax = (x == w - 2) ? 0 : 1;
			for (int i = iMin; i <= iMax; i++)
			{
				for (int j = jMin; j <= jMax; j++)
				{
					float slope = terrain[x + y * w] + subject[x + y * w] - terrain[(x + j) + (y + i) * w] - subject[(x + j) + (y + i) * w];
					if (slope > maxSlope)
					{
						float heightDiff = minf(slope, subject[x + y * w]) * g * dTime;

						subject[(x + j) + (y + i) * w] += heightDiff * 0.2f;
						subject[x + y * w] -= heightDiff * 0.2f;

					}
				}
			}
		}
	}

}

void erodeAndDeposit(float* subject, float* suspendedSubject, float* terrain, fluid_t* medium, vec2f_t* mediumVel, int w, int h){
    // erosion/deposition of sediment
	//  https://ranmantaru.com/blog/2011/10/08/water-erosion-on-heightmap-terrain/
	//  https://old.cescg.org/CESCG-2011/papers/TUBudapest-Jako-Balazs.pdf
	//  https://hal.inria.fr/file/index/docid/402079/filename/FastErosion_PG07.pdf chapter 3.3
	// memcpy(map.sandTemp, map.sand, sizeof(map.sand));
	for (int y = 2; y < h - 3; y++)
	{
		for (int x = 2; x < w - 3; x++)
		{
			// calculate tilt https://math.stackexchange.com/questions/1044044/local-tilt-angle-based-on-height-field
			float tiltX = (terrain[(x + 1) + y * w] + subject[(x + 1) + y * w] - terrain[(x - 1 + y * w)] - subject[(x - 1 + y * w)]) / 2.f;
			float tiltY = (terrain[(x) + (y + 1) * w] + subject[(x) + (y + 1) * w] - terrain[(x + (y - 1) * w)] - subject[(x + (y - 1) * w)]) / 2.f;
			float sinTheta = (sqrtf(tiltX * tiltX + tiltY * tiltY)) / (sqrtf(1 + tiltX * tiltX + tiltY * tiltY));
			float vel = sqrtf(mediumVel[x + y * w].x * mediumVel[x + y * w].x + mediumVel[x + y * w].y * mediumVel[x + y * w].y);
			float Kc = 0.08f;  // sediment capacity constant
			float Ks = 0.09f;  // sediment dissolving constant
			float Kd = 0.03f; // sediment deposition constant

			// sediment transport capacity
			float C = Kc * sinTheta * vel;

			if (C > suspendedSubject[x + y * w]) //If sediment transport capacity is larger than what is currently transported
			{ // Pick up sand
				// Make sure the sand picked up is not more than any nearby tile, creating a pit
				float localMin = terrain[x + y * w] + subject[x + y * w];
				for (int i = -1; i < 2; i++)
				{
					for (int j = -1; j < 2; j++)
					{
						localMin = minf(localMin, terrain[(x + j) + (y + i) * w] + subject[(x + j) + (y + i) * w]);
					}
				}
				float pickedUp = minf(Ks * (C - suspendedSubject[x + y * w]), subject[x + y * w]);
				subject[x + y * w] -= pickedUp;
				suspendedSubject[x + y * w] += pickedUp;
				// medium[x + y * w].depth += pickedUp;
			}
			else if (C <= suspendedSubject[x + y * w])
			{ // Drop sand
				// Make sure dropped sand does not create a peak by not allowing to drop on the local highest point
				float localMax = terrain[x + y * w] + subject[x + y * w];
				for (int i = -1; i < 2; i++)
				{
					for (int j = -1; j < 2; j++)
					{
						localMax = maxf(localMax, terrain[(x + j) + (y + i) * w] + subject[(x + j) + (y + i) * w]);
					}
				}
				if (localMax - terrain[x + y * w] + subject[x + y * w] < 0.001f){
					continue;
                }
				float dropped = Kd * (suspendedSubject[x + y * w] - C);
				subject[x + y * w] += dropped;
				suspendedSubject[x + y * w] -= dropped;
				// medium[x + y * w].depth -= dropped;
			}
			if (medium[x + y * w].depth < 0.001f)
			{
				float dropped = (suspendedSubject[x + y * w]);
				subject[x + y * w] += dropped;
				suspendedSubject[x + y * w] = 0;
				// medium[x + y * w].depth = 0;
			}
		}
	}
}
