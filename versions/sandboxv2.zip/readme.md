Build by running make with command:
C:\msys64\usr\bin\make.exe

Visa källkod i firefox, lägg i länkarn
-gsource-map --source-map-base http://127.0.0.1:5500/


från gammalt projekt 
//emcc main.c -std=c17 -s WASM=1 -s USE_SDL=2 -s -s USE_SDL_IMAGE=2 -s DISABLE_DEPRECATED_FIND_EVENT_TARGET_BEHAVIOR=0 -s SDL2_IMAGE_FORMATS='["png"]' -s TOTAL_MEMORY=536870912 -s USE_PTHREADS=1 -s PTHREAD_POOL_SIZE=4 ^C-preload-file assets -O3 --profiling -o index.js


J. O’Brien and J. K. Hodgins. Dynamic simulation of splash-
ing fluids. In Proceedings of Computer Animation’95, pages
198–205, 1995.
https://smartech.gatech.edu/bitstream/handle/1853/3599/94-32.pdf


Fast Hydraulic Erosion Simulation and Visualization on
GPU
Xing Mei, Philippe Decaudin, Bao-Gang Hu
https://hal.inria.fr/file/index/docid/402079/filename/FastErosion_PG07.pdf