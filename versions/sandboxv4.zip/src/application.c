#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>	//sin/cos /M_PI
#include <string.h> //memcpy

#ifdef __EMSCRIPTEN__
	#include <emscripten.h>
#endif

#ifndef __EMSCRIPTEN__
	#define EMSCRIPTEN_KEEPALIVE
	#define EM_ASM_(...)
	#define EM_ASM(...)
	#define emscripten_run_script
#endif

#include "window.h"
#include "simulation.h"

// Link -lgdi32 -lSDL2_ttf -lSDL2 -lm -lSDL2_image

#ifndef M_PI
	#define M_PI 3.14159265358979323846
#endif

#define DEG2RAD(x) ((x)*(M_PI/180.f))
#define RAD2DEG(x) ((x)*(180.f/M_PI))

#define errLog(message) \
	fprintf(stderr, "\nFile: %s, Function: %s, Line: %d, Note: %s\n", __FILE__, __FUNCTION__, __LINE__, message);

// #define DEBUG

float totalFoamLevel;
float totalSandLevel;
float totalWaterLevel;

struct{
	argb_t white;
	argb_t red;
	argb_t green;
	argb_t blue;
	argb_t yellow;
    argb_t foam;
}pallete = {
	.white.argb   = 0xFFFFFFFF,
	.red.argb     = 0xFFFF0000,
	.green.argb   = 0xFF00FF00,
	.blue.argb    = 0xFF0000FF,
	.yellow.argb  = 0xFFFFFF00,
    .foam.argb    = 0xffedf6f9
};

Layer botLayer;
Layer topLayer;

#define MAPW 256
#define MAPH 256

#define windowSizeX 800
#define windowSizeY 800
#define rendererSizeX 600
#define rendererSizeY 600

static inline float maxf(float a, float b){
    return (a > b) ? a : b;
}

static inline float minf(float a, float b){
    return (a < b) ? a : b;
}

#define max maxf
#define min minf



// #define max(a, b)                \
// 	({                           \
// 		__typeof__(a) _aa = (a); \
// 		__typeof__(b) _bb = (b); \
// 		_aa > _bb ? _aa : _bb;   \
// 	})

// #define min(a, b)               \
// 	({                          \
// 		__typeof__(a) _a = (a); \
// 		__typeof__(b) _b = (b); \
// 		_a < _b ? _a : _b;      \
// 	})

static inline float lerp(float s, float e, float t)
{
	return s + (e - s) * t;
}

static inline float blerp(float c00, float c10, float c01, float c11, float tx, float ty)
{
	//    return lerp(lerp(c00, c10, tx), lerp(c01, c11, tx), ty);
	float s = c00 + (c10 - c00) * tx;
	float e = c01 + (c11 - c01) * tx;
	return (s + (e - s) * ty);
}

typedef struct
{
	uint16_t x, y;
} vec2i16_t;

typedef struct
{
	float x, y, z;
} vec3f_t;


struct
{
	float simSpeed;
} program = {
	.simSpeed = 10.f
    };

struct
{
	int screenX;
	int screenY;
	int worldX;
	int worldY;
	float worldVelX;
	float worldVelY;
	enum
	{
		TOOL_WATER = 1,
		TOOL_SAND = 2,
		TOOL_STONE = 3,
		TOOL_LAVA = 4,
		TOOL_MIST = 5,
		TOOL_FOAM = 6
	} tool;
	float radius;
	float amount;
    struct{
        struct{
            float min;
            float max;
        }radius;
    }limits;
} cursor = {
    .tool = TOOL_WATER,
    .limits.radius.max = 100.f,
    .limits.radius.min = 5.f
    };

typedef struct
{
	float x, y;
	float rot;
	float zoom;
    struct{
        float zoomMax;
        float zoomMin;
    }limits;
	enum
	{
		NE,
		SE,
		SW,
		NW
	} direction;
} camera_t;

camera_t g_cam = {
    .limits.zoomMax = 10.f,
    .limits.zoomMin = 0.03f
};

typedef struct
{
	float height;
	float water;
	argb_t argb;
	float shadow;
} packedMap_t;

struct
{
	int w;
	int h;
	float tileWidth; // width of one tile, used for adjusting fluid simulation
	argb_t argbSed[MAPW * MAPH];
	argb_t argbStone[MAPW * MAPH];
	argb_t argb[MAPW * MAPH];
	float shadowSoft[MAPW * MAPH];
	float shadow[MAPW * MAPH];
	float height[MAPW * MAPH];
	float stone[MAPW * MAPH];
	float sand[MAPW * MAPH];
    struct{
        uint8_t water : 1;
        uint8_t stone : 1;
        uint8_t sand  : 1;
    }present[MAPW * MAPH];
	fluid_t water[MAPW * MAPH];
	vec2f_t waterVel[MAPW * MAPH]; // X/Y
	float susSed[MAPW * MAPH];
	float susSed2[MAPW * MAPH];
	float foamLevel[MAPW * MAPH];
	float foamLevelBuffer[MAPW * MAPH];
	packedMap_t packed[MAPW * MAPH]; // Copy of map data used when rendering, packed for cache friendlyness
	struct
	{
		unsigned int updateShadowMap : 1;
		unsigned int updateColorMap : 1;
	} flags;
} map;

vec2f_t world2screen(float x, float y, camera_t camera)
{
	float sinAlpha = sinf(camera.rot);
	float cosAlpha = cosf(camera.rot);

	// scale for zoom level
	float xs = x / camera.zoom;
	float ys = y / camera.zoom;
	// project

	// rotate
	float xw = cosAlpha * (xs + (camera.x - 614.911)) + sinAlpha * (ys + (camera.y - 119.936)) - (camera.x - 614.911);
	float yw = -sinAlpha * (xs + (camera.x - 614.911)) + cosAlpha * (ys + (camera.y - 119.936)) - (camera.y - 119.936);
	// offset for camPtrera position

	xs = xw + camera.x;
	ys = yw + camera.y;

	xw = ((xs - ys) / sqrtf(2.f));
	yw = ((xs + ys) / sqrtf(6.f));

	vec2f_t retVal = {xw, yw};

	return retVal;
}

vec2f_t screen2world(float x, float y, camera_t camera)
{
	float sinAlpha = sinf(camera.rot);
	float cosAlpha = cosf(camera.rot);
	float sq2d2 = sqrtf(2.f) / 2.f;
	float sq6d2 = sqrtf(6.f) / 2.f;
	// transform screen coordinates to world coordinates
	float xw = sq2d2 * (float)x + sq6d2 * (float)y;
	float yw = sq6d2 * (float)y - sq2d2 * (float)x;
	xw = xw - camera.x;
	yw = yw - camera.y;

	// rotate view
	float xwr = cosAlpha * (xw + (camera.x - 614.911f)) - sinAlpha * (yw + (camera.y - 119.936f)) - (camera.x - 614.911f);
	float ywr = sinAlpha * (xw + (camera.x - 614.911f)) + cosAlpha * (yw + (camera.y - 119.936f)) - (camera.y - 119.936f);
	// 616 121
	// apply zoom
	xw = xwr * camera.zoom;
	yw = ywr * camera.zoom;

	vec2f_t retVal = {xw, yw};
	// double xw = (cosAlpha*(cam.x+sq2d2*x+sq6d2*y-Map.w/2) - sinAlpha*(cam.y+sq6d2*y-sq2d2*x-Map.h/2)+Map.w/2)*cam.zoom;
	// double yw = (sinAlpha*(cam.x+sq2d2*x+sq6d2*y-Map.w/2) + cosAlpha*(cam.y+sq6d2*y-sq2d2*x-Map.h/2)+Map.h/2)*cam.zoom;
	return retVal;
}

void cam_zoom(camera_t* camPtr, float value){
    		// if (camPtr->zoom > camPtr->limits.zoomMin && camPtr->zoom < camPtr->limits.zoomMax){
			float rotation = camPtr->rot; // save camera rotation
			camPtr->rot = 0.f;				 // set camera rotation to 0

			vec2f_t pos1 = screen2world(window.drawSize.w / 2.f, window.drawSize.h / 2.f, g_cam);
			camPtr->zoom += value * camPtr->zoom * window.time.dTime;
            camPtr->zoom = max(min(camPtr->zoom, camPtr->limits.zoomMax), camPtr->limits.zoomMin);
			vec2f_t pos2 = world2screen(pos1.x, pos1.y, g_cam);
			vec2f_t deltapos = {window.drawSize.w / 2.f - pos2.x, window.drawSize.h / 2.f - pos2.y};
			// transform coordinate offset to isometric
			float sq2d2 = sqrtf(2.f) / 2.f;
			float sq6d2 = sqrtf(6.f) / 2.f;
			float xw = sq2d2 * deltapos.x + sq6d2 * deltapos.y;
			float yw = sq6d2 * deltapos.y - sq2d2 * deltapos.x;
			camPtr->y += yw;
			camPtr->x += xw;
			camPtr->rot = rotation; // restore camera rotation
		// }
}

EMSCRIPTEN_KEEPALIVE
void selectToolStone()
{
	cursor.tool = TOOL_STONE;
	printf("Stone\n");
}
EMSCRIPTEN_KEEPALIVE
void selectToolSand()
{
	cursor.tool = TOOL_SAND;
	printf("Sand\n");
}
EMSCRIPTEN_KEEPALIVE
void selectToolWater()
{
	cursor.tool = TOOL_WATER;
	printf("water\n");
}
EMSCRIPTEN_KEEPALIVE
void changeToolRadius(float radius)
{
	cursor.radius = radius;
	printf("radius %f\n", cursor.radius);
}
EMSCRIPTEN_KEEPALIVE
void changeToolAmount(float amount)
{
	cursor.amount = amount;
	printf("amount %f\n", cursor.amount);
}

void updateInput(){
	cursor.screenX = mouse.pos.x;
	cursor.screenY = mouse.pos.y;
	vec2f_t pos = screen2world(cursor.screenX, cursor.screenY, g_cam);
	cursor.worldVelX = (pos.x - (float)cursor.worldX) * window.time.dTime;
	cursor.worldVelY = (pos.y - (float)cursor.worldY) * window.time.dTime;
	cursor.worldX = pos.x;
	cursor.worldY = pos.y;

	if (mouse.left == eKEY_HELD){
		// initialising standard deviation to 1.0
		float sigma = cursor.radius / 4.f; // Width of distribution
		float s = 2.f * sigma * sigma;

		float radius = cursor.radius;
		for (int j = -radius; j <= radius; j++){
			for (int k = -radius; k <= radius; k++){
				float r = sqrtf(k * k + j * j);
				if (r > radius){ continue; } //Skip if outside of cirlce radius

				switch (cursor.tool){
				case TOOL_WATER:
					if (cursor.worldX + k > 2 && cursor.worldY + j > 2 && cursor.worldX + k < map.w - 2 && cursor.worldY + j < map.h - 2){
						map.water[(cursor.worldX + k) + (cursor.worldY + j) * map.w].depth += cursor.radius * cursor.radius * cursor.amount * expf(-(r * r) / (s)) / (M_PI * s) * window.time.dTime;
                        map.present[cursor.worldX+cursor.worldY*map.w].water = 1;
					}
					break;
				case TOOL_SAND:
					if (cursor.worldX + k > 1 && cursor.worldY + j > 1 && cursor.worldX + k < map.w - 1 && cursor.worldY + j < map.h - 1){
						map.sand[(cursor.worldX + k) + (cursor.worldY + j) * map.w] += cursor.radius * cursor.radius * cursor.amount * expf(-(r * r) / (s)) / (M_PI * s) * window.time.dTime;
					}
					break;
				case TOOL_STONE:
					if (cursor.worldX + k > 0 && cursor.worldY + j > 0 && cursor.worldX + k < map.w - 0 && cursor.worldY + j < map.h - 0){
						map.stone[(cursor.worldX + k) + (cursor.worldY + j) * map.w] += cursor.radius * cursor.radius * cursor.amount * expf(-(r * r) / (s)) / (M_PI * s) * window.time.dTime;
					}
					break;
				case TOOL_FOAM:
					if (cursor.worldX + k > 2 && cursor.worldY + j > 2 && cursor.worldX + k < map.w - 2 && cursor.worldY + j < map.h - 2){
						map.foamLevel[(cursor.worldX + k) + (cursor.worldY + j) * map.w] += cursor.radius * cursor.radius * cursor.amount * expf(-(r * r) / (s)) / (M_PI * s) * window.time.dTime;
					}
					break;
				default:

					break;
				}
			}
		}
	}

	if (mouse.right == eKEY_HELD){
		// initialising standard deviation to 1.0
		float sigma = cursor.radius / 4.f; // Width of distribution
		float s = 2.f * sigma * sigma;

		float radius = cursor.radius;
		for (int j = -radius; j <= radius; j++){
			for (int k = -radius; k <= radius; k++){
				float r = sqrtf(k * k + j * j);
				if (r > radius){ continue; } //Skip if outside of cirlce radius

				if (cursor.worldX + k >= 0 && cursor.worldY + j >= 0 && cursor.worldX + k < map.w && cursor.worldY + j < map.h){
					switch (cursor.tool)
					{
					case TOOL_WATER:
						map.water[(cursor.worldX + k) + (cursor.worldY + j) * map.w].depth = max(map.water[(cursor.worldX + k) + (cursor.worldY + j) * map.w].depth - cursor.radius * cursor.radius * cursor.amount * expf(-(r * r) / (s)) / (M_PI * s) * window.time.dTime, 0.f);
						break;
					case TOOL_SAND:
						map.sand[cursor.worldX + k + (cursor.worldY + j) * map.w] = max(map.sand[cursor.worldX + k + (cursor.worldY + j) * map.w] - cursor.radius * cursor.radius * cursor.amount * expf(-(r * r) / (s)) / (M_PI * s) * window.time.dTime, 0.f);
						break;
					case TOOL_STONE:
						map.stone[cursor.worldX + k + (cursor.worldY + j) * map.w] = max(map.stone[cursor.worldX + k + (cursor.worldY + j) * map.w] - cursor.radius * cursor.radius * cursor.amount * expf(-(r * r) / (s)) / (M_PI * s) * window.time.dTime, 5.f);
						break;
					default:
						break;
					}
				}
			}
		}
		map.flags.updateShadowMap = 1;
	}

	if (key.A == eKEY_HELD){
		g_cam.x += cosf(g_cam.rot - (M_PI / 4.f)) * 300.f * window.time.dTime;
		g_cam.y += sinf(g_cam.rot - (M_PI / 4.f)) * 300.f * window.time.dTime;
	}
	if (key.D == eKEY_HELD){
		g_cam.x -= cosf(g_cam.rot - (M_PI / 4.f)) * 300.f * window.time.dTime;
		g_cam.y -= sinf(g_cam.rot - (M_PI / 4.f)) * 300.f * window.time.dTime;
	}
	if (key.W == eKEY_HELD){
		g_cam.x -= sinf(g_cam.rot - (M_PI / 4.f)) * 450.f * window.time.dTime;
		g_cam.y += cosf(g_cam.rot - (M_PI / 4.f)) * 450.f * window.time.dTime;

		// Print camera pos
		// printf("camera: x:%f y:%f rot:%f zoom:%f", g_cam.x, g_cam.y, g_cam.rot, g_cam.zoom);
	}
	if (key.S == eKEY_HELD){
		g_cam.x += sinf(g_cam.rot - (M_PI / 4.f)) * 450.f * window.time.dTime;
		g_cam.y -= cosf(g_cam.rot - (M_PI / 4.f)) * 450.f * window.time.dTime;
	}
	if (key.R == eKEY_HELD){
		cam_zoom(&g_cam, 1.f);
	}
	if (key.F == eKEY_HELD){
        cam_zoom(&g_cam, -1.f);
	}
	if (key.Q == eKEY_HELD){
		float angle = 32.f * M_PI / 180.f;
		g_cam.rot = fmod((g_cam.rot - angle * 2.f * window.time.dTime), 6.283185307f);
		if (g_cam.rot < 0.f)
			g_cam.rot = 6.283185307f;
	}
	if (key.E == eKEY_HELD){
		float angle = 32.f * M_PI / 180.f;
		g_cam.rot = fmod((g_cam.rot + angle * 2.f * window.time.dTime), 6.283185307f);
	}
	if (key.ESC == eKEY_HELD){
		window.closeWindow = true;
	}

	if (key.num1 == eKEY_PRESSED){
		cursor.tool = TOOL_STONE;
		EM_ASM(Stone.checked = true;);
	}

	if (key.num2 == eKEY_PRESSED){
		cursor.tool = TOOL_SAND;
		EM_ASM(Sand.checked = true;);
	}

	if (key.num3 == eKEY_PRESSED){
		cursor.tool = TOOL_WATER;
		EM_ASM(Water.checked = true;);
	}

	if (key.num9 == eKEY_PRESSED){
		cursor.tool = TOOL_FOAM;
	}



	if(mouse.dWheel){
		if(key.shiftLeft == eKEY_HELD){

            cam_zoom(&g_cam, mouse.dWheel);

		}else if(key.ctrlLeft == eKEY_HELD){
			cursor.amount += mouse.dWheel;
			cursor.amount = min(max(cursor.amount, 1.f), 10.f);
				EM_ASM_({
				toolAmountAmount.value = $0;
				toolAmountSlider.value = $0;
			}, cursor.amount);
		}else{
			cursor.radius += mouse.dWheel;
			cursor.radius = min(max(cursor.radius, cursor.limits.radius.min), cursor.limits.radius.max);
			EM_ASM_({
				toolRadiusAmount.value = $0;
				toolRadiusSlider.value = $0;
			},cursor.radius);
		}
	}



	if (key.K == eKEY_HELD){
		errLog("shit pommes");
		for(int i=0;i<99;i++){
			printf("spam\n");
		}
	}
}

void water_update(fluid_t* fluid, float g, float l, float A, float friction, float dTime)
{
	float* T = map.stone;
	fluid_t* f = fluid; // shorter name

	for (int y = 2; y < MAPH - 2; y++)
	{
		int yw = y * MAPW;
		for (int x = 2; x < MAPW - 2; x++)
		{
            if(!map.present[x+y*map.w].water) continue;

			f[x + yw].right = max(f[x + yw].right * friction + (f[x + yw].depth + T[x + yw] + map.sand[x + yw] - f[(x + 1) + (yw)].depth - T[(x + 1) + yw] - map.sand[(x + 1) + yw]) * dTime * A * g / l, 0.f);					   
			f[x + yw].down  = max(f[x + yw].down  * friction + (f[x + yw].depth + T[x + yw] + map.sand[x + yw] - f[(x) + (y + 1) * MAPW].depth - T[(x) + (y + 1) * MAPW] - map.sand[(x) + (y + 1) * MAPW]) * dTime * A * g / l, 0.f); 
			f[x + yw].left  = max(f[x + yw].left  * friction + (f[x + yw].depth + T[x + yw] + map.sand[x + yw] - f[(x - 1) + (yw)].depth - T[(x - 1) + yw] - map.sand[(x - 1) + yw]) * dTime * A * g / l, 0.f);						   
			f[x + yw].up    = max(f[x + yw].up    * friction + (f[x + yw].depth + T[x + yw] + map.sand[x + yw] - f[(x) + (y - 1) * MAPW].depth - T[(x) + (y - 1) * MAPW] - map.sand[(x) + (y - 1) * MAPW]) * dTime * A * g / l, 0.f);	  

			// make sure flow out of cell isn't greater than inflow + existing fluid
			if (f[x + yw].depth - (f[x + yw].right + f[x + yw].down + f[x + yw].left + f[x + yw].up) < 0)
			{
				float K = min(f[x + yw].depth * l * l / ((f[x + yw].right + f[x + yw].down + f[x + yw].left + f[x + yw].up) * dTime), 1.f);
				f[x + yw].right *= K;
				f[x + yw].down *= K;
				f[x + yw].left *= K;
				f[x + yw].up *= K;
			}
		}
	}
	// border conditions
	for (int y = 0; y < MAPH; y++)
	{
		f[(MAPW - 3) + y * MAPW].right = 0;
		f[3 + y * MAPW].left = 0;
	}
	for (int x = 0; x < MAPW; x++)
	{
		f[x + 3 * MAPW].up = 0;
		f[x + (MAPH - 3) * MAPW].down = 0;
	}


	// update depth
	for (int y = 2; y < MAPH - 2; y++)
	{
		for (int x = 2; x < MAPW - 2; x++)
		{
			float deltaV = (f[(x - 1) + (y)*MAPW].right + f[(x) + (y + 1) * MAPW].up + f[(x + 1) + (y)*MAPW].left + f[(x) + (y - 1) * MAPW].down - (f[(x) + (y)*MAPW].right + f[(x) + (y)*MAPW].down + f[(x) + (y)*MAPW].left + f[(x) + (y)*MAPW].up)) * dTime;
			//            if(deltaV < 0.0001f && deltaV > -0.0001) continue;
			f[(x) + (y)*MAPW].depth = max(f[(x) + (y)*MAPW].depth + deltaV / (l * l), 0.f);


			// calculate velocity
			map.waterVel[x + y * map.w].x = (f[(x - 1) + (y)*MAPW].right - f[(x) + (y)*MAPW].left + f[(x) + (y)*MAPW].right - f[(x + 1) + (y)*MAPW].left) / (2.f); // X
			map.waterVel[x + y * map.w].y = (f[(x) + (y - 1)*MAPW].down - f[(x) + (y)*MAPW].up + f[(x) + (y)*MAPW].down - f[(x) + (y + 1)*MAPW].up) / (2.f);       // Y

            if((f[(x) + (y)*MAPW].depth) < 0.01f){
                map.present[x+y*map.w].water = 0;
                map.water[x + y * map.w].right = 0;
                map.water[x + y * map.w].down = 0;
                map.water[x + y * map.w].left = 0;
                map.water[x + y * map.w].up = 0;
            }else{
                map.present[x+y*map.w].water = 1;
            }
		}
	}



}

int R = 20;
int Rmin = 1;
int Rmax = 40;
float A = 1.f;
float Amin = -2.f;
float Amax = 2.f;

float shadow[MAPW * MAPH];
void generateShadowMap()
{
	map.flags.updateShadowMap = 0;

	// TODO: move this height update somewhere else
	for (int i = 0; i < map.w * map.h; i++)
	{
		map.height[i] = map.stone[i] + map.sand[i];
	}

	float scale = 2;

	// Copy heap stored variables to stack before calculation
	int mapW = map.w;
	int mapH = map.h;
	for (int i = 0; i < mapW * mapH; i++)
		shadow[i] = 0.90f;

	//		Calculate shadows by iterating over map diagonally like example below.
	//		------- Save the highest tileheight in diagonal and decrease by 1 each step.
	//		|6|3|1| If current tile is higher, save that one as new highest point.
	//		|8|5|2| If not then that tile is in shadow.
	//		|9|7|4|
	//		------- ONLY WORKS ON SQUARE MAPS!!!
	//
	int diagonalLines = (mapW + mapH) - 1;	// number of diagonal lines in map
	int midPoint = (diagonalLines / 2) + 1; // number of the diagonal that crosses midpoint of map
	int itemsInDiagonal = 0;				// stores number of tiles in a diagonal

	for (int diagonal = 1; diagonal <= diagonalLines; diagonal++)
	{
		float terrainPeakHeight = 1;
		int x, y;
		if (diagonal <= midPoint)
		{
			itemsInDiagonal++;
			for (int item = 0; item < itemsInDiagonal; item++)
			{
				y = (diagonal - item) - 1;
				x = mapW - item - 1;
				terrainPeakHeight -= 0.5f * A;
				if (terrainPeakHeight > map.height[x + y * mapW])
				{
					if ((terrainPeakHeight - map.height[x + y * mapW]) > 2.f)
					{
						shadow[x + y * mapW] -= 0.10f;
					}
					else
					{
						//At the edge of the shadow, interpolate between shaded value and no shade
						shadow[x + y * mapW] -= 0.05f * (terrainPeakHeight - map.height[x + y * mapW]);
					}
				}
				else
				{
					terrainPeakHeight = map.height[x + y * mapW];
				}
				//Add shading based on angle
				//TODO: Will sample outside shadow map 
				shadow[x+y*map.w] += min(max(((map.height[(x-1)+(y-1)*map.w] - map.height[(x+1)+(y+1)*map.w]) / 20.f), -0.05f), 0.05f);
			}
		}
		else
		{
			itemsInDiagonal--;
			for (int item = 0; item < itemsInDiagonal; item++)
			{
				y = (mapH - 1) - item;
				x = diagonalLines - diagonal - item;
				terrainPeakHeight -= 0.5f * A;
				if (terrainPeakHeight > map.height[x + y * mapW])
				{
					if ((terrainPeakHeight - map.height[x + y * mapW]) > 2.f)
					{
						shadow[x + y * mapW] -= 0.1f;
					}
					else
					{
						//At the edge of the shadow, interpolate between shaded value and no shade
						shadow[x + y * mapW] -= 0.05f * (terrainPeakHeight - map.height[x + y * mapW]);
					}
				}
				else
				{
					terrainPeakHeight = map.height[x + y * mapW];
				}
				//Add shading based on angle
				//TODO: Will sample outside shadow map 
				shadow[x+y*map.w] += min(max(((map.height[(x-1)+(y-1)*map.w] - map.height[(x+1)+(y+1)*map.w]) / 20.f), -0.05f), 0.05f);
			}
		}
	}

	// ambient occlusion
	// Calculate ambient occlusion using a box filter, optimized with technique found here: http://blog.ivank.net/fastest-gaussian-blur.html#results

	//	int R = 20;
	// float diameterDiv = 1.f / (R + 1 + R);
	// for (int i = 0; i < mapH; i++)
	// {
	// 	int ti = i * mapW;
	// 	int li = ti;
	// 	int ri = ti + R;
	// 	float fv = map.height[ti];
	// 	float lv = map.height[ti + mapW - 1];
	// 	float val = (float)(R + 1) * fv;
	// 	for (int j = 0; j < R; j++)
	// 	{
	// 		val += map.height[ti + j];
	// 	}
	// 	for (int j = 0; j <= R; j++)
	// 	{
	// 		val += map.height[ri++] - fv;
	// 		shadow[ti] += ((map.height[ti]) - (val * diameterDiv));
	// 		ti++;
	// 	}
	// 	for (int j = R + 1; j < mapW - R; j++)
	// 	{
	// 		val += map.height[ri++] - map.height[li++];
	// 		shadow[ti] += ((map.height[ti]) - (val * diameterDiv));
	// 		ti++;
	// 	}
	// 	for (int j = mapW - R; j < mapW; j++)
	// 	{
	// 		val += lv - map.height[li++];
	// 		shadow[ti] += ((map.height[ti]) - (val * diameterDiv));
	// 		ti++;
	// 	}
	// }
	// for (int i = 0; i < mapW; i++)
	// {
	// 	int ti = i;
	// 	int li = ti;
	// 	int ri = ti + R * mapW;
	// 	float fv = map.height[ti];
	// 	float lv = map.height[ti + mapW * (mapH - 1)];
	// 	float val = (float)(R + 1) * fv;
	// 	for (int j = 0; j < R; j++)
	// 	{
	// 		val += map.height[ti + j * mapW];
	// 	}
	// 	for (int j = 0; j <= R; j++)
	// 	{
	// 		val += map.height[ri] - fv;
	// 		shadow[ti] += ((map.height[ti]) - (val * diameterDiv));
	// 		ri += mapW;
	// 		ti += mapW;
	// 	}
	// 	for (int j = R + 1; j < mapH - R; j++)
	// 	{
	// 		val += map.height[ri] - map.height[li];
	// 		shadow[ti] += ((map.height[ti]) - (val * diameterDiv));
	// 		li += mapW;
	// 		ri += mapW;
	// 		ti += mapW;
	// 	}
	// 	for (int j = mapH - R; j < mapH; j++)
	// 	{
	// 		val += lv - map.height[li];
	// 		shadow[ti] += ((map.height[ti]) - (val * diameterDiv));
	// 		li += mapW;
	// 		ti += mapW;
	// 	}
	// }

	// smooth shadows
	//	boxBlur_4(shadow,map.shadow,mapW*mapH,mapW,mapH,1);
	//	boxBlur_4(map.shadow,shadow,mapW*mapH,mapW,mapH,1);
	//	boxBlur_4(shadow,map.shadow,mapW*mapH,mapW,mapH,10);
	// smoother shadows
	//	boxBlur_4(shadow,map.shadowSoft,mapW*mapH,mapW,mapH,4);

	for(int y=0;y<map.h/2;y++){
		for(int x=0;x<map.w;x++){
			// shadow[x+y*map.w] += (map.height[(x)+(y)*map.w] - map.height[(x+1)+(y+1)*map.w] + map.height[(x-1)+(y-1)*map.w] - map.height[(x)+(y)*map.w]) / 2.f;
		}
	}

	for(int y=map.h/2;y<map.h;y++){
		for(int x=0/2;x<map.w;x++){
			// shadow[x+y*map.w] += sqrtf((map.height[(x)+(y)*map.w] - map.height[(x+1)+(y+1)*map.w])*(map.height[(x)+(y)*map.w] - map.height[(x+1)+(y+1)*map.w]) + (map.height[(x-1)+(y-1)*map.w] - map.height[(x)+(y)*map.w])*(map.height[(x-1)+(y-1)*map.w] - map.height[(x)+(y)*map.w]));
		}
	}

	for (int i = 0; i < mapW * mapH; i++){
		// shadow[i] = 0.5f + shadow[i];
	}

	//Clamp shadow value
	for (int i = 0; i < mapW * mapH; i++){
		// shadow[i] = min(max(shadow[i], 0.40f), 0.60f);
	}

	memcpy(map.shadow, shadow, sizeof(shadow));
}

void generateColorMap()
{
	map.flags.updateColorMap = false;

	for (int y = 0; y < map.h; y++)
	{
		int mapPitch = y * map.w;
		for (int x = 0; x < map.w; x++)
		{
			float t = min(map.sand[x + mapPitch], 1.0f);
			map.argb[x + mapPitch].r = lerp(map.argbStone[x + mapPitch].r, map.argbSed[x + mapPitch].r, t);
			map.argb[x + mapPitch].g = lerp(map.argbStone[x + mapPitch].g, map.argbSed[x + mapPitch].g, t);
			map.argb[x + mapPitch].b = lerp(map.argbStone[x + mapPitch].b, map.argbSed[x + mapPitch].b, t);
		}
	}
}

void process(float dTime)
{

		//foam
		//spawn foam where water is turbulent
		for(int y=1;y<map.h-1;y++){
			for(int x=1;x<map.w-1;x++){

	//			float velX = map.waterVel[x+y*map.w].x;
	//			float velY = map.waterVel[x+y*map.w].y;
				//curl is something, velDiff is speed difference with nearby tiles
	//			float curl = map.waterVel[(x+1)+y*map.w].y - map.waterVel[(x-1)+y*map.w].y - map.waterVel[x+(y+1)*map.w].x + map.waterVel[x+(y-1)*map.w].y;
				float velDiff = map.waterVel[x+y*map.w].x*2 - map.waterVel[(x-1)+(y)*map.w].x - map.waterVel[(x+1)+(y)*map.w].x + map.waterVel[x+y*map.w].y*2 - map.waterVel[x+(y-1)*map.w].y - map.waterVel[x+(y+1)*map.w].y;
				// float deltaV = (map.water[(x-1)+(y)*MAPW].right+map.water[(x)+(y+1)*MAPW].down+map.water[(x+1)+(y)*MAPW].left+map.water[(x)+(y-1)*MAPW].up - (map.water[(x)+(y)*MAPW].right+map.water[(x)+(y)*MAPW].down+map.water[(x)+(y)*MAPW].left+map.water[(x)+(y)*MAPW].up));

				if(velDiff > 1.f){
					map.foamLevel[x+y*map.h] += 0.25f;
				}

			}
		}


	water_update(map.water, 9.81f, 1.f, 1.f, 0.9999f, min(dTime*program.simSpeed, 0.15f));

    
    erodeAndDeposit(map.sand, map.susSed, map.stone, map.water, map.waterVel, map.w, map.h);
    relax(map.sand, map.stone, 40.f, 9.81f, map.w, map.h, min(dTime*program.simSpeed, 0.15f)); 
    advect(map.susSed, map.susSed2, map.waterVel, map.w, map.h, min(dTime*program.simSpeed, 0.15f));

    //Advect the foam
    advect(map.foamLevel, map.foamLevelBuffer, map.waterVel, map.w, map.h, min(dTime*program.simSpeed, 0.15f));

    //Count the total amount of foam on map, and evaporate some foam
    totalFoamLevel = 0.f;
    for(int i = 0; i < map.w*map.h; i++){
        map.foamLevel[i] -= min(map.foamLevel[i],0.02f);
        totalFoamLevel += map.foamLevel[i];
    }

    //Count total amount of sand
    totalSandLevel = 0.f;
    for(int i = 0; i < map.w*map.h; i++){
        totalSandLevel += map.sand[i];
    }

}

argb_t getTileColorWater(int x, int y, int ys, vec2f_t upVec, float shade)
{

	shade = min(shade, 1.f);
	int r = 0, g = 0, b = 0;
	int posID = x + y * map.w;
	float wtrHeight = map.water[x + y * map.w].depth;
	// calculate slope of water for highlighting and caustics
	//		float slopX = -map.water[4+(x+1)*5 + (y)*map.w*5] + map.water[4+(x-1)*5 + (y)*map.w*5] - map.stone[(x+1) + (y)*map.w] + map.stone[(x-1) + (y)*map.w];
	float slopX = -map.water[(x + 1) + y * map.w].depth + map.water[(x - 1) + y * map.w].depth - map.height[(x + 1) + (y)*map.w] + map.height[(x - 1) + (y)*map.w];
	//		float slopY = map.water[4+(x)*5 + (y-1)*map.w*5] - map.water[4+(x)*5 + (y+1)*map.w*5] + map.stone[(x) + (y-1)*map.w] - map.stone[(x) + (y+1)*map.w];
	float slopY = map.water[x + (y - 1) * map.w].depth - map.water[x + y * map.w].depth + map.height[(x) + (y - 1) * map.w] - map.height[(x) + (y + 1) * map.w];
	if (0)
	{ // fancy water
		int test2 = 0;
		int underwaterFoam = 0; // use this shit
		for (int i = 0; i < (int)wtrHeight + 1; i++)
		{
			int seaFloorPosX = (x + (int)(upVec.x * i));
			int seaFloorPosY = (y + (int)(upVec.y * i));
			//				underwaterFoam += max((int)(map.suSed[seaFloorPosX+seaFloorPosY*map.w]*200) - i*5,0) ;
			if (map.height[seaFloorPosX + seaFloorPosY * map.w] >= wtrHeight * 2 - (float)i * 1.25)
			{
				test2 = (x + (int)(upVec.x * i)) + (y + (int)(upVec.y * i)) * map.w;
				int newX = (x + (int)(upVec.x * i));
				int newY = (y + (int)(upVec.y * i));
				float caustic = 0;
				if (!(seaFloorPosX <= 2 || seaFloorPosX >= map.w - 2 || seaFloorPosY <= 2 || seaFloorPosY >= map.h - 2))
				{
					//						caustic =  (map.water[4+(newX+1)*5+newY*map.w*5] - map.water[4+(newX-1)*5+newY*map.w*5] + map.stone[test2+1] - map.stone[test2-1] +
					caustic = (map.water[(newX + 1) + newY * map.w].depth - map.water[(newX - 1) + newY * map.w].depth + map.height[test2 + 1] - map.height[test2 - 1] +
							   //							map.water[4+(newX)*5+(newY+1)*map.w*5] - map.water[4+(newX)*5+(newY-1)*map.w*5] + map.stone[test2+1*map.w] - map.stone[test2-1*map.w])*10;
							   map.water[(newX) + (newY + 1) * map.w].depth - map.water[(newX) + (newY - 1) * map.w].depth + map.height[test2 + 1 * map.w] - map.height[test2 - 1 * map.w]) * 10.f;
				}
				float foamShadow = 0; // map.foamLevel[test2] * 0.2;
				underwaterFoam = max(min(underwaterFoam, 100), 0);

				r = min(map.argb[posID].r + map.sand[posID] * 202.f * 0.5f, 202.f); // map.argb[test2].r ;//+ (-caustic - foamShadow + underwaterFoam*0.5f)*(1-min(shade,1.0f));
				g = min(map.argb[posID].r + map.sand[posID] * 188.f * 0.5f, 188.f); // map.argb[test2].g ;//+ (-caustic - foamShadow + underwaterFoam*0.5f)*(1-min(shade,1.0f));
				b = min(map.argb[posID].r + map.sand[posID] * 145.f * 0.5f, 145.f); // map.argb[test2].b ;//+ (-caustic - foamShadow + underwaterFoam)*(1-min(shade,1.0f));

				// lerp between hard and soft shadows depending on the depth
				int shadow;
				//					if(map.water[4+(newX)*5+(newY)*map.w*5] < 10){ //interpolate between hard and soft shadows
				if (map.water[(newX) + (newY)*map.w].depth < 10)
				{ // interpolate between hard and soft shadows
					//						shadow = map.shadow[test2] + (map.shadowSoft[test2] - map.shadow[test2])*(min(map.water[4+(newX)*5+(newY)*map.w*5]/10.f,1.f));
					shadow = map.shadow[test2] + (map.shadowSoft[test2] - map.shadow[test2]) * (min(map.water[(newX) + (newY)*map.w].depth / 10.f, 1.f));
				}
				else
				{ // interpolate between soft and no shadows
					//						shadow = map.shadowSoft[test2] + (0 - map.shadowSoft[test2])*(min(map.water[4+(newX)*5+(newY)*map.w*5]/100.f,1.f));
					shadow = map.shadowSoft[test2] + (0 - map.shadowSoft[test2]) * (min(map.water[(newX) + (newY)*map.w].depth / 100.f, 1.f));
				}
				r -= 0; // shadow;
				g -= 0; // shadow;
				b -= 0; // shadow;
				break;
			}
			if (seaFloorPosX < 1 || seaFloorPosX >= map.w - 1 || seaFloorPosY < 1 || seaFloorPosY >= map.h - 1)
			{
				r = (102 + (int)ys) >> 2; // 67
				g = (192 + (int)ys) >> 2; // 157
				b = (229 + (int)ys) >> 2; // 197
				break;
			}
		}
	}else{ // unfancy water
		//			int seaFloorPosX = (x+(int)(upVec.x*wtrHeight));
		//			int seaFloorPosY = (y+(int)(upVec.y*wtrHeight));
		////			float foamShadow = 0;
		//			float caustic = 0;
		//			if(seaFloorPosX > 2 && seaFloorPosX < map.w-2 && seaFloorPosY > 2 && seaFloorPosY < map.h-2){
		//				int seaFloorPos = seaFloorPosX+seaFloorPosY*map.w;
		////				foamShadow = map.foamLevel[seaFloorPos] * 0.1;
		////				caustic =  (map.water[4+(seaFloorPosX+1)*5+(seaFloorPosY)*map.w*5] - map.water[4+(seaFloorPosX-1)*5+(seaFloorPosY)*map.w*5] + map.stone[seaFloorPos+1] - map.stone[seaFloorPos-1] +
		//				caustic =  (map.water[(seaFloorPosX+1)+(seaFloorPosY)*map.w].depth - map.water[(seaFloorPosX-1)+(seaFloorPosY)*map.w].depth + map.height[seaFloorPos+1] - map.height[seaFloorPos-1] +
		////										map.water[4+(seaFloorPosX)*5+(seaFloorPosY+1)*map.w*5] - map.water[4+(seaFloorPosX)*5+(seaFloorPosY-1)*map.w*5] + map.stone[seaFloorPos+1*map.w] - map.stone[seaFloorPos-1*map.w])*10;
		//										map.water[(seaFloorPosX)+(seaFloorPosY+1)*map.w].depth - map.water[(seaFloorPosX)+(seaFloorPosY-1)*map.w].depth + map.height[seaFloorPos+1*map.w] - map.height[seaFloorPos-1*map.w])*10;
		//			}
		////			r =	map.argb[posID].r + (caustic - foamShadow)*(1-shade);
		////			g =	map.argb[posID].g + (caustic - foamShadow)*(1-shade);
		////			b =	map.argb[posID].b + (caustic - foamShadow)*(1-shade);
	
		r = map.packed[posID].argb.r ; 
		g = map.packed[posID].argb.g ; 
		b = map.packed[posID].argb.b ; 
	}

	if (1){ // water surface

		// highligt according to slope
		r += -13 - wtrHeight * 4 + (slopX * slopX + slopY * slopY) * 1;
		g += -8 - wtrHeight * 2 + (slopX * slopX + slopY * slopY) * 2;
		b += -5 - wtrHeight * 1 + (slopX * slopX + slopY * slopY) * 2;
		// if slope is certain angle, make water whiter to look like glare from sun
		if (slopX + slopY > 0.1 && slopX + slopY < 1)
		{
			if (slopX + slopY > 0.5 && slopX + slopY < 1)
			{
				r += 30 * (1 - min(shade, 1.0f));
				g += 30 * (1 - min(shade, 1.0f));
				b += 30 * (1 - min(shade, 1.0f));
			}
			else
			{
				r += 10 * (1 - min(shade, 1.0f));
				g += 10 * (1 - min(shade, 1.0f));
				b += 10 * (1 - min(shade, 1.0f));
			}
		}

		// reflections
		//			for(int i=0;i<100;i++){
		//				int reflectionPosX = (x+(int)(upVec.x*i));
		//				int reflectionPosY = (y+(int)(upVec.y*i));
		//				if(map.stone[reflectionPosX+reflectionPosY*map.w] >= map.stone[x+y*map.w] + wtrHeight + (float)i*0.75f){
		//
		//					r = map.argb[reflectionPosX+reflectionPosY*map.w].r;
		//					g = map.argb[reflectionPosX+reflectionPosY*map.w].g;
		//					b = map.argb[reflectionPosX+reflectionPosY*map.w].b;
		//					break;
		//				}
		//			}
	}
	

	// draw foam
	if (map.foamLevel[x + y * map.w] > 0)
	{
		r = lerp(r, pallete.foam.r, min(map.foamLevel[posID] / 20.f, 1.f));
		g = lerp(g, pallete.foam.g, min(map.foamLevel[posID] / 20.f, 1.f));
		b = lerp(b, pallete.foam.b, min(map.foamLevel[posID] / 20.f, 1.f));
	}

	
	// if (map.susSed[x + y * map.w] > 0)
	// {
	// 	r += map.susSed[x + y * map.w] * 202.f / 4.f;
	// 	g += map.susSed[x + y * map.w] * 188.f / 4.f;
	// 	b += map.susSed[x + y * map.w] * 145.f / 2.f;
	// }
	// apply shadow on water
	// float shadow = map.shadow[x + y * map.w] * (1 - min(shade, 1.0f));

	r *= map.packed[posID].shadow;
	g *= map.packed[posID].shadow;
	b *= map.packed[posID].shadow;

	argb_t returnRGB;
	returnRGB.r = min(max((int)r, 0), 255);
	returnRGB.g = min(max((int)g, 0), 255);
	returnRGB.b = min(max((int)b, 0), 255);

	return returnRGB;
}
argb_t frameBuffer[rendererSizeX * rendererSizeY];
argb_t background[rendererSizeX * rendererSizeY]; // Stores background image that get copied to framebuffer at start of render

// renders one pixel column
void renderColumn(int x, int yBot, int yTop, vec2f_t upVec, float xwt, float ywt, float dDxw, float dDyw, camera_t camera)
{
	// save some variables as local

	// init some variables

	int border = false; // used when skiping pixels to decide when at a edge of a tile that should be a darker shade
	int dPixels;		// how many pixels are skipped to get to the next tile

	// init ybuffer with lowest mappoint at current x screen position
	// ybuffer stores the last drawn lowest position so there is no overdraw

	int ybuffer = min(yBot, window.drawSize.h); // Limit lowest drawing point (ybuffer start value) to edge of screen

	// start drawing column
	for (int y = yBot; y > yTop; y -= dPixels)
	{
		int ys;

		int ywti = (int)ywt;
		int xwti = (int)xwt;
		packedMap_t mapPack = map.packed[xwti + ywti * map.w];
		float camZoom = camera.zoom;
		float camZoomDiv = 1.f / camera.zoom;

		//        float gndHeight = map.packed[posID].height;//map.stone[posID] + map.sand[posID]; //not using map.height ensures instant terrain update, map.height is okay for blurry/unclear renderings as underwater
		//        float wtrHeight = map.packed[posID].water; //map.water[posID].depth;
		float mistHeight = 0; // Map.mistHeight[posID];
		float lavaHeight = 0; // Map.lavaHeight[posID];

		ys = y - (mapPack.height) * camZoomDiv; // offset y by terrain height
		ys = ys * !(ys & 0x80000000);			// Non branching version of : ys = max(ys, 0);

		if (ys < ybuffer)
		{
			// get color at worldspace and draw at screenspace
			register argb_t argb; // store color of Pixel that will be drawn

			// draw mist if present
			if (mistHeight > 0.f)
			{
				//	rgb mistRGB = getTileColorMist(xwti, ywti, ys, upVec);
				//	r = mistRGB.r;
				//	g = mistRGB.g;
				//	b = mistRGB.b;
			}
			else if (map.present[xwti + ywti*map.w].water)
			{ // draw water if present
				argb = getTileColorWater(xwti, ywti, ys, upVec, 0.f);
			}
			else if (lavaHeight > 0.f)
			{ // draw lava if present
				//	rgb lavaRGB = getTileColorLava(xwti, ywti, 0.f);
				//	r = lavaRGB.r;
				//	g = lavaRGB.g;
				//	b = lavaRGB.b;
			}
			else
			{ // only ground
				//				xwt + ywt*map.w;  	202, 188, 145
				argb = mapPack.argb;
				if (map.foamLevel[xwti + ywti * map.w] > 0)
				{
					argb.r = lerp(argb.r, pallete.foam.r, min(map.foamLevel[xwti + ywti * map.w] / 20.f, 1.f));
					argb.g = lerp(argb.g, pallete.foam.g, min(map.foamLevel[xwti + ywti * map.w] / 20.f, 1.f));
					argb.b = lerp(argb.b, pallete.foam.b, min(map.foamLevel[xwti + ywti * map.w] / 20.f, 1.f));
				}
				argb.r *= mapPack.shadow;
				argb.g *= mapPack.shadow;
				argb.b *= mapPack.shadow;
			}

			// calculate and draw cursor branchlessly
			// argb.g += 30 * (((uint32_t)(((xwti - cursor.worldX) * (xwti - cursor.worldX) +
			// 							 (ywti - cursor.worldY) * (ywti - cursor.worldY)) -
			// 							((int)(cursor.radius) << 4)) &
			// 				 0x80000000) >>
			// 				31);

			if((xwti - cursor.worldX) * (xwti - cursor.worldX) + (ywti - cursor.worldY) * (ywti - cursor.worldY) < cursor.radius*4){ //Why *4?
				switch (cursor.tool)
				{
				case TOOL_WATER:
					argb.r = lerp(argb.r, pallete.blue.r, 0.1f + 0.02f*cursor.amount);
					argb.g = lerp(argb.g, pallete.blue.g, 0.1f + 0.02f*cursor.amount);
					argb.b = lerp(argb.b, pallete.blue.b, 0.1f + 0.02f*cursor.amount);
					break;
				case TOOL_SAND:
					argb.r = lerp(argb.r, pallete.yellow.r, 0.1f + 0.02f*cursor.amount);
					argb.g = lerp(argb.g, pallete.yellow.g, 0.1f + 0.02f*cursor.amount);
					argb.b = lerp(argb.b, pallete.yellow.b, 0.1f + 0.02f*cursor.amount);
					break;
				case TOOL_STONE:
					argb.r = lerp(argb.r, pallete.white.r, 0.1f + 0.02f*cursor.amount);
					argb.g = lerp(argb.g, pallete.white.g, 0.1f + 0.02f*cursor.amount);
					argb.b = lerp(argb.b, pallete.white.b, 0.1f + 0.02f*cursor.amount);
					break;
				case TOOL_FOAM:
					argb.r = lerp(argb.r, pallete.green.r, 0.1f + 0.02f*cursor.amount);
					argb.g = lerp(argb.g, pallete.green.g, 0.1f + 0.02f*cursor.amount);
					argb.b = lerp(argb.b, pallete.green.b, 0.1f + 0.02f*cursor.amount);
					break;
				default:
					errLog("");
					break;
				}
				
			}




			// make borders of tiles darker, make it so they become darker the more zoomed in you are
			if (camZoom < 0.3f && !border)
			{

				argb.r -= camZoomDiv;
				argb.g -= camZoomDiv;
				argb.b -= camZoomDiv;
			}

			// clamp color values
			//			argb = (min(max(r,0),255) << 16) | (min(max(g,0),255) << 8) | (min(max(b,0),255)); //85-87

			//                argb = (argb_t) {
			//                        .r = CLAMP(r, 0, 255),
			//                        .g = CLAMP(g, 0, 255),
			//                        .b = CLAMP(b, 0, 255)
			//                };
			//                    ((CLAMP(r,0,255)) << 16) | ((CLAMP(g,0,255)) << 8) | (CLAMP(b,0,255)); //86-90

			// only draw visible pixels
			for (register int Y = ybuffer - 1; Y >= ys; Y--)
			{
				//            for (register int Y = ys ; Y < ybuffer ; Y++) {
				//                int ix = rendTexture.h - (ybuffer-ys) + Y + (x) * rendTexture.h;

				//                frameBuffer[ix] = argb;    //draw pixels
				frameBuffer[window.drawSize.h - 1 - Y + (x)*window.drawSize.h] = argb; // draw pixels
				// TODO: change to memset
			}

			ybuffer = ys; // save current highest point in pixel column
		}

		// this piece of code calculates how many y pixels (dPixels) there is to the next tile
		// and the border thing makes it so it only jumps one pixel when there is a
		// new tile and the next drawing part is darker, thus making the edge of the tile darker
		if (!border)
		{ //! border
			border = 1;
			float testX, testY;
			switch (camera.direction)
			{
			case NW:
				testX = ((xwt - (int)xwt)) / dDxw;
				testY = ((ywt - (int)ywt)) / dDyw;
				break;
			case NE:
				testX = ((1 - (xwt - (int)xwt)) / dDxw);
				testY = (((ywt - (int)ywt)) / dDyw);
				break;
			case SE:
				testX = (1 - (xwt - (int)xwt)) / dDxw;
				testY = (1 - (ywt - (int)ywt)) / dDyw;
				break;
			case SW:
				testX = (((xwt - (int)xwt)) / dDxw);
				testY = ((1 - (ywt - (int)ywt)) / dDyw);
				break;
			default:
				fprintf(stderr, "Unitialized value used at %s %d\n", __FILE__, __LINE__);
				exit(0);
			}
			dPixels = min(fabs(testX), fabs(testY));
			if (dPixels < 1)
				dPixels = 1;
			xwt += dDxw * dPixels;
			ywt += dDyw * dPixels;
		}
		else
		{

			border = 0;
			xwt += dDxw;
			ywt += dDyw;
			dPixels = 1;
		}
	}
}

void render()
{
	// Since this runs on a separate thread from input update I need to back up camera variables so they don't change during rendering
	camera_t cam;
	cam.rot = g_cam.rot;
	cam.zoom = g_cam.zoom;
	cam.x = g_cam.x;
	cam.y = g_cam.y;
	cam.direction = g_cam.direction;

	// Copy background to framebuffer
	memcpy(frameBuffer, background, sizeof(frameBuffer));



	float xw, yw;
	float xs, ys;

	// furstum
	xs = 0;
	ys = 0;
	vec2f_t ftl = screen2world(xs, ys, cam);
	xs = window.drawSize.w;
	ys = window.drawSize.h;
	vec2f_t fbr = screen2world(xs, ys, cam);
	xs = 0;
	ys = window.drawSize.h;
	vec2f_t fbl = screen2world(xs, ys, cam);
	xs = 0;
	ys = window.drawSize.h + 100.f / cam.zoom;

	float dDxw = (ftl.x - fbl.x) / (float)window.drawSize.h; // delta x worldspace depth
	float dDyw = (ftl.y - fbl.y) / (float)window.drawSize.h; // delta y worldspace depth

	// create normalized vector that point up on the screen but in world coorinates, for use with raytracing water refraction
	vec2f_t upVec = {ftl.x - fbl.x, ftl.y - fbl.y};
	float tempDistLongName = sqrtf(upVec.x * upVec.x + upVec.y * upVec.y);
	upVec.x /= tempDistLongName;
	upVec.y /= tempDistLongName;

	///////// merge these calculations later
	// calculate screen coordinates of world corners
	vec2f_t tlw = world2screen(1, 1, cam);
	vec2f_t trw = world2screen(map.w, 1, cam);
	vec2f_t blw = world2screen(1, map.h, cam);
	vec2f_t brw = world2screen(map.w, map.h, cam);
	// check what relative postion map corners have
	vec2f_t mapCornerTop, mapCornerLeft, mapCornerBot, mapCornerRight;
	switch (cam.direction)
	{
	case NW:
		mapCornerTop = (vec2f_t){tlw.x, tlw.y};
		mapCornerLeft = (vec2f_t){blw.x, blw.y};
		mapCornerBot = (vec2f_t){brw.x, brw.y};
		mapCornerRight = (vec2f_t){trw.x, trw.y};
		break;
	case NE:
		mapCornerRight = (vec2f_t){brw.x, brw.y};
		mapCornerTop = (vec2f_t){trw.x, trw.y};
		mapCornerLeft = (vec2f_t){tlw.x, tlw.y};
		mapCornerBot = (vec2f_t){blw.x, blw.y};
		break;
	case SE:
		mapCornerBot = (vec2f_t){tlw.x, tlw.y};
		mapCornerRight = (vec2f_t){blw.x, blw.y};
		mapCornerTop = (vec2f_t){brw.x, brw.y};
		mapCornerLeft = (vec2f_t){trw.x, trw.y};
		break;
	case SW:
		mapCornerLeft = (vec2f_t){brw.x, brw.y};
		mapCornerBot = (vec2f_t){trw.x, trw.y};
		mapCornerRight = (vec2f_t){tlw.x, tlw.y};
		mapCornerTop = (vec2f_t){blw.x, blw.y};
		break;
	default:
		fprintf(stderr, "Unitialized value used at %s %d\n", __FILE__, __LINE__);
		exit(0);
		break;
	}

	// calculate slope of tile edges on screen
	float tileEdgeSlopeRight = (float)(mapCornerRight.y - mapCornerBot.y) / (float)(mapCornerRight.x - mapCornerBot.x);
	float tileEdgeSlopeLeft = (float)(mapCornerBot.y - mapCornerLeft.y) / (float)(mapCornerBot.x - mapCornerLeft.x);
	/////////

	// these coordinates will be the bounds at which renderColumn() will render any terrain
	int leftMostXCoord = max((int)mapCornerLeft.x, 0);
	int rightMostXCoord = min((int)mapCornerRight.x, window.drawSize.w);

	for (int x = leftMostXCoord; x < rightMostXCoord; x++)
	{
		int botMostYCoord;
		int topMostYCoord;

		if (x > mapCornerBot.x)
		{
			botMostYCoord = mapCornerBot.y + tileEdgeSlopeRight * (x - mapCornerBot.x);
		}
		else
		{
			botMostYCoord = mapCornerBot.y + tileEdgeSlopeLeft * (x - mapCornerBot.x);
		}
		if (x > mapCornerTop.x)
		{
			topMostYCoord = mapCornerTop.y + tileEdgeSlopeLeft * (x - mapCornerTop.x);
		}
		else
		{
			topMostYCoord = mapCornerTop.y + tileEdgeSlopeRight * (x - mapCornerTop.x);
		}

		topMostYCoord = topMostYCoord * !(topMostYCoord & 0x80000000); // Branchless topMostYCoord = max(topMostYCoord, 0);

		vec2f_t worldCoord = screen2world(x, botMostYCoord, cam);

		renderColumn(x, botMostYCoord, topMostYCoord, upVec, worldCoord.x, worldCoord.y, dDxw, dDyw, cam);
	}

	// for memory access pattern reasons the terrain gets drawn sideways. That's why we below transpose the framebuffer while copying it to rendTexture
	for (int y = 0; y < window.drawSize.h; y++)
	{
		int pixelPitch = y * window.drawSize.w;
		int bufferPitch = window.drawSize.h - 1 - y;
		for (int x = 0; x < window.drawSize.w; x++)
		{
			botLayer.frameBuffer[x + pixelPitch] = frameBuffer[bufferPitch + (x)*window.drawSize.w];
		}
	}
}

void generateTerrain()
{
	int w = MAPW;
	int h = MAPH;

	srand(1.f);

	for (int y = 0; y < h; y++)
	{
		for (int x = 0; x < w; x++)
		{
			map.stone[x + y * w] = 10.f;
			// map.stone[x+y*w] = 10.f + sqrtf((w/2-x)*(w/2-x)+(h/2-y)*(h/2-y))/2.f;
			//            map.stone[x+y*w]  = 100.f +
			//                    64.f*sin((float)((x*o1+y*o2))/(128.f)) +
			//                    32.f*sin((float)((x*o3+y*o4))/64.f) +
			//                    16.f*sin((float)((x*o5+y*o6))/32.f) +
			//                    8.f*sin((float)((x*o7+y*o8))/16.f) +
			//                    4.f*sin((float)((x*o9+y*o1))/8.f) +
			//                    2.f*sin((float)((x*o2+y*o3))/4.f);
			//                    1.0f*sin((float)((x*o2+y*o3))/2.f) +
			//                    0.5f*sin((float)((x*o3+y*o4))/1.f) +
			//                    0.25f*sin((float)((x*o5+y*o6))/0.5f) +
			//                    0.125f*sin((float)((x*o7+y*o8))/0.25f);
			map.argb[x + y * w].r = 150;
			map.argb[x + y * w].g = 150;
			map.argb[x + y * w].b = 150;
		}
		printf("\rGenerating terrain %f", (float)y / (float)h);
		fflush(stdout);
	}
}

void init()
{

	map.w = MAPW;
	map.h = MAPH;
	map.tileWidth = 1.f;

	// init camera position, the following will init camera to center overview a 256x256 map
	// camera: x:336.321991 y:-93.287224 rot:1.570000 zoom:0.609125camera: x:327.101379 y:-84.052345 rot:1.570000 zoom:0.609125
	g_cam.x = 221.321991;
	g_cam.y = 21.287224;
	g_cam.rot = 3.14f / 2;
	g_cam.zoom = 0.609125;

	//Init tool values
	cursor.amount = 10;
	cursor.radius = 15;
	cursor.tool = TOOL_WATER;

	//Call javascript that synchronise initialized settings with html gui
	switch (cursor.tool)
	{
	case TOOL_WATER:
		EM_ASM(Water.checked = true;);
		break;
	case TOOL_SAND:
		EM_ASM(Sand.checked = true;);
		break;	
	case TOOL_STONE:
		EM_ASM(Stone.checked = true;);
		break;
	default:
		break;
	}
	//set html sliders
	EM_ASM_({
		toolAmountAmount.value = $0;
		toolAmountSlider.value = $0;
		toolRadiusAmount.value = $1;
		toolRadiusSlider.value = $1;
    }, cursor.amount, cursor.radius);


	generateTerrain();

	map.flags.updateShadowMap = 1; // make sure shadows are updated after map load
	map.flags.updateColorMap = 1;  // make sure shadows are updated after map load

	// Create background for render
	for (int x = 0; x < window.drawSize.w; x++)
	{
		argb_t argb = (argb_t){.b = ((219 + x) >> 2), .g = (((182 + x) >> 2)), .r = (((92 + x) >> 2))};
		for (int y = 0; y < window.drawSize.h; y++)
		{

			background[window.drawSize.w - 1 - x + y * window.drawSize.w] = argb;
		}
	}

	// Generate initial stone rgb map

	for (int y = 0; y < map.h; y++)
	{
		for (int x = 0; x < map.w; x++)
		{
			map.argbStone[x + y * map.w].r = 150;
			map.argbStone[x + y * map.w].g = 150;
			map.argbStone[x + y * map.w].b = 150;
		}
	}
	// generate initial sand rgb map
	for (int y = 0; y < map.h; y++)
	{
		for (int x = 0; x < map.w; x++)
		{
			map.argbSed[x + y * map.w].r = 202;
			map.argbSed[x + y * map.w].g = 188;
			map.argbSed[x + y * map.w].b = 145;
		}
	}
}

void drawPoint(Layer layer, int x, int y, argb_t color){
	if(x >= layer.w || x < 0 || y >= layer.h || y < 0){
		// errLog(printfLocal("(%d,%d) Out of bounds", x, y));
		return;
	}

	layer.frameBuffer[x+y*layer.w] = color;
}

void drawLine(Layer layer, int xStart, int yStart, int xEnd, int yEnd, argb_t color){
	int outOfBounds = 0; //If both point are outside bounds we return from this funciton before drawing anything
	if(xStart >= layer.w || xStart < 0 || yStart >= layer.h || yStart < 0){
		// errLog(printfLocal("(%d,%d) Out of bounds", xStart, yStart));
		xStart = min(max(xStart, 0), layer.w-1);
		yStart = min(max(yStart, 0), layer.h-1);
		outOfBounds++;
	}
	if(xEnd >= layer.w || xEnd < 0 || yEnd >= layer.h || yEnd < 0){
		// errLog(printfLocal("(%d,%d) Out of bounds", xStart, yStart));
		xEnd = min(max(xEnd, 0), layer.w-1);
		yEnd = min(max(yEnd, 0), layer.h-1);
		outOfBounds++;
	}
	if(outOfBounds >= 2) return;



	int dx = xEnd - xStart;
	int dy = yEnd - yStart;

	 // calculate steps required for generating pixels
	int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

	// calculate increment in x & y for each steps
	float Xinc = dx / (float) steps;
	float Yinc = dy / (float) steps;

	// Put pixel for each step
	float X = xStart;
	float Y = yStart;
	for (int i = 0; i <= steps; i++)
	{
		int x = round(X);
		int y = round(Y);
		layer.frameBuffer[(x)+(y)*layer.w] = color;
		X += Xinc;           // increment in x at each step
		Y += Yinc;           // increment in y at each step

	}
}

int mainLoop()
{

	clearLayer(botLayer);
	clearLayer(topLayer);

	char titleString[100];
	sprintf(titleString, "fps: %f, ms: %f", window.time.fps, window.time.dTime);
	// if(window.time.tick.ms100) window_setTitle(titleString);

	updateInput();

	if (fabs(g_cam.rot) < 45.f * M_PI / 180.f || fabs(g_cam.rot) >= 315.f * M_PI / 180.f)
	{
		g_cam.direction = NW;
	}
	else if (fabs(g_cam.rot) < 135.f * M_PI / 180.f)
	{
		g_cam.direction = NE;
	}
	else if (fabs(g_cam.rot) < 225.f * M_PI / 180.f)
	{
		g_cam.direction = SE;
	}
	else if (fabs(g_cam.rot) < 315.f * M_PI / 180.f)
	{
		g_cam.direction = SW;
	}
	else
	{
		fprintf(stderr, "Unitialized value used at %s %d\n", __FILE__, __LINE__);
		exit(0);
	}


	process(window.time.dTime);



	if (window.time.tick.ms10 || map.flags.updateShadowMap == true)
	{
		generateShadowMap();
	}

	if (window.time.tick.ms1 || map.flags.updateColorMap == true)
	{
		generateColorMap();
		for (int y = 0; y < map.h; y++)
		{
			for (int x = 0; x < map.w; x++)
			{
				map.packed[x + y * map.w].height = map.sand[x + y * map.w] + map.stone[x + y * map.w] + map.water[x + y * map.w].depth;
				map.packed[x + y * map.w].water = map.water[x + y * map.w].depth;
				map.packed[x + y * map.w].argb = map.argb[x + y * map.w];
				map.packed[x + y * map.w].shadow = map.shadow[x + y * map.w];
			}
		}
	}

	render();

	drawText(topLayer, 10, 10, printfLocal(titleString, "fps: %.2f, ms: %,2f", window.time.fps, window.time.dTime));

#ifdef DEBUG
    int cwx = min(max(cursor.worldX, 0), map.w);
    int cwy = min(max(cursor.worldY, 0), map.h);
	drawText(topLayer, 10, 30, printfLocal("Mouse: %d, %d | %d, %d | %f %f", mouse.pos.x, mouse.pos.y, cwx, cwy, map.waterVel[cwx+cwy*map.w].x, map.waterVel[cwx+cwy*map.w].y) );
	drawText(topLayer, 10, 50, printfLocal("Shadow: %f", map.shadow[cwx+cwy*map.w]));
	drawText(topLayer, 10, 70, printfLocal("foam: %f total: %f", map.foamLevel[cwx+cwy*map.w], totalFoamLevel));
	drawText(topLayer, 10, 90, printfLocal("Sand: %f total: %f", map.sand[cwx+cwy*map.w], totalSandLevel));

    //Draw water is present data
	for (int y = 0; y < map.h; y++)
	{
		for (int x = 0; x < map.w; x++)
		{
            if(map.present[x+y*map.w].water){
                vec2f_t sPos = world2screen((float)x+0.5f,(float)y+0.5f,g_cam);
                sPos.y = sPos.y - (map.height[x+y*map.w] + map.water[x+y*map.w].depth)  / g_cam.zoom;
                drawPoint(topLayer, sPos.x, sPos.y, pallete.red);
            }
        }
    }

	//Draw water velocity markers
	for (int y = 0; y < map.h; y++)
	{
		if((y % 10)) continue;
		for (int x = 0; x < map.w; x++)
		{
			if((x % 10)) continue;
			float x2 = x + map.waterVel[x + y * map.w].x;
			float y2 = y + map.waterVel[x + y * map.w].y;
			vec2f_t sPos = world2screen((float)x+0.5f,(float)y+0.5f,g_cam);
			vec2f_t sPos2 = world2screen((float)x2+0.5f,(float)y2+0.5f,g_cam);
			// sPos.y = sPos.y - (map.height[x+y*map.w] + map.water[x+y*map.w].depth)  / g_cam.zoom;
			// sPos2.y = sPos2.y - (map.height[x+y*map.w] + map.water[x+y*map.w].depth)  / g_cam.zoom;
			// float vel = sqrtf((map.waterVel[x + y * map.w].x*map.waterVel[x + y * map.w].x)+(map.waterVel[x + y * map.w].y*map.waterVel[x + y * map.w].y));
			// drawLine(topLayer, sPos.x,sPos.y, sPos2.x, sPos2.y, pallete.white);
			// drawPoint(topLayer, sPos.x, sPos.y, pallete.red);
		}
	}

	//Draw mouse position
	for (int y = -1; y < 1; y++)
	{
		for (int x = -1; x < 1; x++)
		{
			if (mouse.pos.x > 1 && mouse.pos.x < window.drawSize.w - 1)
			{
				if (mouse.pos.y > 1 && mouse.pos.x < window.drawSize.h - 1)
				{
					topLayer.frameBuffer[(mouse.pos.x + x) + (mouse.pos.y + y) * topLayer.w].argb = 0xFFFFFFFF;
				}
			}
		}
	}
#endif


	return window_run();
}


int main()
{
	// Disable console buffering
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);

	window.drawSize.w = rendererSizeX;
	window.drawSize.h = rendererSizeY;
	window.size.w = windowSizeX;
	window.size.h = windowSizeY;

	window_init();

	// init bottom layer
	botLayer = window_createLayer();
	// init top layer
	topLayer = window_createLayer();

	init();

#ifdef __EMSCRIPTEN__
	emscripten_set_main_loop((void (*)(void))mainLoop, 0, 1);
#else
	while (mainLoop())
	{
	}
#endif

	return 0;
}


